package com.beatflow.music

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF202020)
private val Green = Color(0xFF1ED760)
private val Muted = Color(0xFFB3B3B3)

data class Track(val uri: Uri, val title: String, val artist: String)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { BeatFlowScreen(player) }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BeatFlowScreen(player: ExoPlayer) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tracks by remember { mutableStateOf(listOf<Track>()) }
    var currentIndex by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Home") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val added = uris.map { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfter(':') ?: "Audio track"
            Track(uri, name.substringBeforeLast('.', name), "Local audio")
        }
        tracks = (tracks + added).distinctBy { it.uri }
    }

    LaunchedEffect(player) {
        while (true) {
            playing = player.isPlaying
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.takeIf { it > 0 } ?: 0L
            delay(500)
        }
    }

    fun playAt(index: Int) {
        if (index !in tracks.indices) return
        currentIndex = index
        player.setMediaItem(MediaItem.fromUri(tracks[index].uri))
        player.prepare()
        player.play()
        playing = true
    }

    val filtered = tracks.withIndex().filter {
        it.value.title.contains(query, ignoreCase = true) ||
            it.value.artist.contains(query, ignoreCase = true)
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            Column(Modifier.background(Bg)) {
                if (currentIndex in tracks.indices) {
                    MiniPlayer(
                        track = tracks[currentIndex],
                        playing = playing,
                        onPlayPause = { if (player.isPlaying) player.pause() else player.play() },
                        onOpen = { tab = "Now Playing" }
                    )
                }
                NavigationBar(containerColor = Color(0xFF080808), contentColor = Color.White) {
                    listOf("Home", "Search", "Your Library").forEach { label ->
                        val icon = when (label) {
                            "Home" -> Icons.Default.Home
                            "Search" -> Icons.Default.Search
                            else -> Icons.Default.LibraryMusic
                        }
                        NavigationBarItem(
                            selected = tab == label,
                            onClick = { tab = label },
                            icon = { Icon(icon, null) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green,
                                selectedTextColor = Green,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted,
                                indicatorColor = Panel
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding)
                .background(Bg).padding(horizontal = 18.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("BEATFLOW", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text(when(tab) { "Search" -> "Find your sound"; "Your Library" -> "Your Library"; "Now Playing" -> "Now Playing"; else -> "Good music. Good mood." },
                        color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(42.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.GraphicEq, null, tint = Green)
                }
            }

            when (tab) {
                "Now Playing" -> {
                    if (currentIndex in tracks.indices) {
                        NowPlaying(
                            track = tracks[currentIndex], playing = playing,
                            position = position, duration = duration,
                            onSeek = { player.seekTo(it) },
                            onPlayPause = { if (player.isPlaying) player.pause() else player.play() },
                            onNext = { if (tracks.isNotEmpty()) playAt((currentIndex + 1) % tracks.size) },
                            onPrevious = { if (tracks.isNotEmpty()) playAt(if (currentIndex <= 0) tracks.lastIndex else currentIndex - 1) }
                        )
                    } else EmptyLibrary { picker.launch(arrayOf("audio/*")) }
                }
                else -> {
                    if (tab == "Home") {
                        Text("Made for your moments", color = Muted, fontSize = 14.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FeatureCard("Your tracks", "${tracks.size} songs", Icons.Default.MusicNote, Modifier.weight(1f)) { tab = "Your Library" }
                            FeatureCard("Add music", "From this phone", Icons.Default.Add, Modifier.weight(1f)) { picker.launch(arrayOf("audio/*")) }
                        }
                        Spacer(Modifier.height(22.dp))
                    } else if (tab == "Search") {
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search your local songs", color = Muted) },
                            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Green, unfocusedBorderColor = Panel,
                                cursorColor = Green
                            )
                        )
                        Spacer(Modifier.height(16.dp))
                    } else {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Your music", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                                Icon(Icons.Default.Add, null, tint = Green)
                                Text(" Add songs", color = Green)
                            }
                        }
                    }

                    if (tracks.isEmpty()) {
                        EmptyLibrary { picker.launch(arrayOf("audio/*")) }
                    } else {
                        Text(if (tab == "Home") "Recently added" else "Songs (${filtered.size})",
                            color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 10.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            itemsIndexed(filtered) { _, indexed ->
                                val index = indexed.index
                                TrackRow(tracks[index], index == currentIndex, onClick = { playAt(index) })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).clickable { onClick() }.padding(14.dp)) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(25.dp))
        Spacer(Modifier.height(15.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun EmptyLibrary(onAdd: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 42.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.LibraryMusic, null, tint = Green, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(12.dp))
        Text("Your music starts here", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Add audio files stored on your phone.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)) {
            Icon(Icons.Default.Add, null)
            Text("  Choose songs", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TrackRow(track: Track, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).background(Panel, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, null, tint = Green, modifier = Modifier.size(24.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(track.title, color = if (selected) Green else Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.MoreHoriz, null, tint = Muted)
    }
}

@Composable
fun MiniPlayer(track: Track, playing: Boolean, onPlayPause: () -> Unit, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
            .background(Color(0xFF282828), RoundedCornerShape(10.dp))
            .clickable { onOpen() }.padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Album, null, tint = Green, modifier = Modifier.size(32.dp))
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(track.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onPlayPause) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
        }
    }
}

@Composable
fun NowPlaying(
    track: Track, playing: Boolean, position: Long, duration: Long,
    onSeek: (Long) -> Unit, onPlayPause: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).padding(horizontal = 18.dp)
            .background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Album, null, tint = Green, modifier = Modifier.size(110.dp))
        }
        Spacer(Modifier.height(26.dp))
        Text(track.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(track.artist, color = Muted, fontSize = 15.sp)
        Spacer(Modifier.height(22.dp))
        Slider(
            value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..(duration.coerceAtLeast(1).toFloat()),
            colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green, inactiveTrackColor = Panel)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = Muted, fontSize = 11.sp)
            Text(formatTime(duration), color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
            IconButton(onClick = onPlayPause, modifier = Modifier.size(66.dp).background(Green, CircleShape)) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(38.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
        }
    }
}

fun formatTime(ms: Long): String {
    val total = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0))
    return "%d:%02d".format(total / 60, total % 60)
}
