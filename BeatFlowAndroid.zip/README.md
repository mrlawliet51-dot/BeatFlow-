# BeatFlow Android

A Spotify-inspired local music player starter app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Included
- Dark music-player interface with green accent
- Pick multiple audio files from Android's document picker
- Local library list and title search
- Playback with play/pause, previous/next and seek bar
- Mini-player and full now-playing screen

## Build
1. Open this folder in Android Studio (Hedgehog or newer; current stable recommended).
2. Allow Gradle to sync and download dependencies.
3. Select the `app` run configuration and run on an Android device or emulator.
4. To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The APK is typically created at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This starter plays audio files selected from the device. It does not stream Spotify's catalogue or provide Spotify account access.
- Music files must be available on the device and playable by Android Media3.
- This is an original demo brand and interface, not an official Spotify application.
